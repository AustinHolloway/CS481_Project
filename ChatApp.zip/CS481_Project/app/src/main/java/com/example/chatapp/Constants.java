package com.example.chatapp;

public class Constants {
    public static final String IMAGES_FOLDER = "images";
    public static final String REQUEST_STATUS_SENT = "sent";
    public static final String REQUEST_STATUS_RECEIVED = "received";
}
