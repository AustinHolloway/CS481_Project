package com.example.chatapp;

public class UserInfo {
    public String name, birthday, username;

    public UserInfo()
    {

    }

    public UserInfo(String name, String birthday, String username)
    {
        this.birthday = birthday;
        this.name = name;
        this.username = username;
    }

}
